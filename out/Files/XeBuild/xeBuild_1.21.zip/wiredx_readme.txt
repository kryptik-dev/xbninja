When using a wired controller's guide button to turn on the xbox, different powerup reasons are created internally.
 As of now, the default for 'wiredx' is the back USB port on fat consoles, and the bottom (when horozontal) usb port on slims.

These settings apply to wireless controllers with play and charge connected to the console, but not uniformly. Sometimes
 they will give a wirelessx reason, and sometimes they give one of the wiredx reasons.

You can choose to have a specific port for this purpose when assigning a poweron reason or alternate
 poweron reason, when the console is laying flat instead of up on its side:

wiredxb1 - slim back top plug, fat none
wiredxb2 - slim back middle plug, fat none
wiredxb3 - default, slim back bottom plug, fat back plug
wiredxf1 - slim front left plug, fat front top plug
wiredxf2 - slim front right plug, fat front bottom plug
